import React, { Component } from 'react';
import {
    Text,
    TouchableOpacity,
    View ,
    ScrollView,
    Image,
    commentData,
    Alert,
    
} from 'react-native'
import {PageContext} from "../../App";
import MaterialSnackbar from "../../components/MaterialSnackbar";
import {storageImageUrl} from "../../tools/Helpers";
import HeaderThreeButton from "../../components/HeaderThreeButton";
import MaterialInput from "../../components/MaterialInput";
import MaterialButton from "../../components/MaterialButton";
// import styles from "../style/Indexstyle";
import FloatingButton from "../../components/FloatingButton";




class ActivityApp extends Component {
    constructor(props) {
        super(props);
        this.state = {
           person:1,
            Data : []
        }
    }
    componentDidMount(){
        const item= this.props.route.params.item
        this.setState({Data:item})
    }
    render() {
        return (
            <View style={{flex: 1, backgroundColor: '#f1f5f7'}}>
           
            <ScrollView>
                <View style={{flexDirection: 'row'}}>
            <View style={{
                flex: 1,
                backgroundColor: 'white',
                borderRadius: 3,
                shadowRadius: 3,
                elevation: 3,
                shadowOffset: {width: 0, height: 2},
                shadowOpacity: 0.3
            }}>
                <Image source={{uri: this.state.Data.HotelActivityImage}}
                       style={{height: 190, width: '100%', resizeMode: 'stretch'}}/>
                <View style={{padding: 15, flexDirection: 'row', alignItems: 'center'}}>
                    <View style={{flex: 1, marginLeft: 10,}}>
                        <Text style={{fontSize: 14}}>
                            <Text style={{fontWeight: 'bold', color: '#616161',textAlign:"center"}}>{this.state.Data.HotelActivityTitle}</Text>
                        </Text>
                    </View>
                    {/* <TouchableOpacity>
                        <Text style={{fontSize: 14, color: '#2979ff'}}>Like</Text>
                    </TouchableOpacity> */}
                </View>
                <View style={{width: '100%', height: 0.5, backgroundColor: '#e0e0e0'}}/>
                <Text style={{fontSize: 14, color: '#616161', padding: 15, lineHeight: 20}}>{this.state.Data.HotelActivityDesc}</Text>
                <View style={{width: '100%', height: 0.5, backgroundColor: '#e0e0e0'}}/>
                <View style = {{height:50, justifyContent:"center"}}>
                <Text style={{fontSize: 12, marginLeft: 5, padding: 15, color: '#616161'}}>
                           <Text style = {{fontWeight:"bold"}}>Price: </Text>  
                            {this.state.Data.Price} $</Text>
                </View>
                <View style={{width: '100%', height: 0.5, backgroundColor: '#e0e0e0'}}/>
                <View style={{flexDirection: 'row', alignItems: 'center', marginTop: 20}}>
                    <Text style={{fontSize: 14, color: '#616161', padding: 15, lineHeight: 20, fontWeight:"bold"}}>Number of Person</Text>
                        <FloatingButton size={34} style={{backgroundColor: '#ff7900', position: 'relative'}}
                                        image={require('../../assets/icon/ic_minus.png')}
                                        imageStyle={{tintColor: 'white', width: 20, height: 20}}
                                        onPress={() => this.state.person>1?this.setState({person:this.state.person - 1}):console.log("0")}/>
                        <Text style={{width: 50, textAlign: 'center', fontSize: 14, color: '#bdbdbd'}}>{this.state.person}</Text>
                        <FloatingButton size={34} style={{backgroundColor: '#ff7900', position: 'relative'}}
                                        image={require('../../assets/icon/ic_plus.png')}
                                        imageStyle={{tintColor: 'white', width: 20, height: 20}}
                                        onPress={() =>  this.setState({person:this.state.person + 1})}/>

                    </View>       
                    {/* <View style={{width: '100%', height: 0.5, backgroundColor: '#e0e0e0'}}/>     */}
                <View style={{
                    width: '100%',
                    // flexDirection: 'row',
                    marginBottom: 15,
                    padding: 15,
                    alignItems: 'center',
                    justifyContent: 'space-between',
                }}>
                    
                   
                     <MaterialButton title='Book' style={{width: 73, borderRadius: 3, backgroundColor: '#ff7900'}}
                            // buttonPress={() => Alert.alert("Book Pressed")}
                            // buttonPress={() => this.Book1()}
                            // onPress={this.Book1}
                    /> 
                   </View>
                
            </View>
        </View>
    
              </ScrollView>
            {/* <MaterialSnackbar ref={snackbarRef}/> */}
        </View>
    );
}
}
export default ActivityApp; 