import React, { Component } from 'react';
import {
    Text,
    TouchableOpacity,
    View ,
    Button
} from 'react-native'
import { BarCodeScanner } from 'expo-barcode-scanner';
import styles from "../style/Indexstyle";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Menuside from "../src/Menuside";
import Barcode from "../src/Barcode";



class SignUpApp extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }
    
                // this.storeData();
                async componentDidMount(){
                  const { status } = await  BarCodeScanner.requestPermissionsAsync();
                        this.setState({hasPermission :status === 'granted'})
                        if(status === 'granted'){
                        this.props.navigation.navigate("Barcode")
                        }
                console.log(status)
                }
               
    render() {
      return (
        <View style = {{marginTop: 50}}>
          <Text style = {{textAlign: "center"}}>{this.state.hasPermission == undefined? "Please Wait":"Please give perision for camera"}</Text>
          {/* <Button title = "Go" onPress={()=>this.props.navigation.navigate("Barcode")}/> */}
        </View>
      );
    }
  }
export default SignUpApp;
        